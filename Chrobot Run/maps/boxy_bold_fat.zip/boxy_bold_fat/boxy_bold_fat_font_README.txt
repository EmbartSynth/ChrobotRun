boxy bold fat font

a 'fat' bottom version of boxy bold font

derivative author
Scott Matott

original authors
Clint Bellanger
and
usr_share

original from:
http://opengameart.org/content/boxy-bold-font-0


license = public domain

About:

I took Clint and usr_share's font, made it one pixel wider and
added an extra row to the bottoms of the characters to give
it a 'fat bottom' look.
I also hand stretched the font 2x in height to create a 'tall' varient.
Finally, I added a base and tip to the 1, mostly to make all the numbers
monospaced, but also because I just like 1's that way. :)

Dimensions should generally be 8x8, and 8x16 for the tall version, 
although a few characters (M, W, ...) are 9 pixels wide, and some
are only 7 pixels wide (most of the lower case letters).

Also included for good measure are several fill styles I created in various
colors. 
They are:
'gradient' - a smooth gradient I created using GIMP 'Cool Metal' filter
'edged' - a simple edge treatment I created by hand
'aa' - an attempt to give the font a more 'rounded' look via hand drawn anti-aliasing
        (don't think this came out all too well, but including anyway)







